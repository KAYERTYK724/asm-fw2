import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Nav } from 'react-bootstrap';
import { FaUserEdit, FaTachometerAlt, FaCube } from 'react-icons/fa';
import './style.css';

const SidebarAdmin = () => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const userData = localStorage.getItem("user");
        if (userData) {
            setUser(JSON.parse(userData));
        }
    }, []);
    return (
        <div className="sidebar pe-4 pb-3">
            <nav className="navbar bg-secondary navbar-dark">
                {/* Logo */}
                <a href="/admin/dashboard" className="navbar-brand mx-4 mb-3">
                    <h3 className="text-primary"><FaUserEdit className="me-2" />DarkPan</h3>
                </a>

                {/* User info */}
                <div className="d-flex align-items-center ms-4 mb-4">
                    <div className="position-relative">
                        <img
                            className="rounded-circle"
                            src="https://i.pinimg.com/736x/70/09/21/7009214dd03308c20f6cf142b93886b6.jpg"
                            alt="User"
                            style={{ width: '40px', height: '40px', objectFit: 'cover' }}
                        />
                        <div className="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
                    </div>
                    <div className="ms-3">
                        <h6 className="mb-0 text-white">
                            {user ? user.fullname || user.fullname : "Admin"}
                        </h6>
                        <small>Quản trị viên</small>
                    </div>
                </div>

                <Nav className="navbar-nav w-100 flex-column">
                    <Nav.Link as={Link} to='/admin/dashboard' className="active"><FaTachometerAlt className="me-2" />DASHBOARD</Nav.Link>
                    <Nav.Link as={Link} to='/admin/category'><FaCube className="me-2" />DANH MỤC</Nav.Link>
                    <Nav.Link as={Link} to='/admin/productAdmin'><FaCube className="me-2" />SẢN PHẨM</Nav.Link>
                    <Nav.Link as={Link} to='/admin/comment'><FaCube className="me-2" />BÌNH LUẬN</Nav.Link>
                    <Nav.Link as={Link} to='/admin/orders'><FaCube className="me-2" />ĐƠN HÀNG</Nav.Link>
                    <Nav.Link as={Link} to='/admin/blogAdmin'><FaCube className="me-2" />BÀI VIẾT</Nav.Link>
                    <Nav.Link as={Link} to='/admin/user'><FaCube className="me-2" />NGƯỜI DÙNG</Nav.Link>
                </Nav>
            </nav>
        </div>
    );
};

export default SidebarAdmin;