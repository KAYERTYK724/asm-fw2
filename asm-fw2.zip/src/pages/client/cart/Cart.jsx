/* eslint-disable react-hooks/exhaustive-deps */
import './style.css';
import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import requestAPI from '../../../RequestAPI';

const Cart = () => {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();

  // ✅ check login
  useEffect(() => {
    const token = localStorage.getItem('token');

    if (!token) {
      alert('Vui lòng đăng nhập!');
      navigate('/login');
    }
  }, []);

  // ✅ load cart từ API
  useEffect(() => {
    const fetchCart = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));

        if (!user) return;

        const res = await requestAPI({
          method: 'GET',
          url: `/orders/cart/${user.id}`,
        });

        setItems(res.data.data);
      } catch (error) {
        console.log('Lỗi load cart:', error);
      }
    };

    fetchCart();
  }, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  // ✅ update số lượng (API)
  const updateQty = async (id, value) => {
    if (isNaN(value) || value < 1) value = 1;

    try {
      await requestAPI({
        method: 'PUT',
        url: `/orders/update-cart/${id}`,
        data: { quantity: value },
      });

      setItems((prev) =>
        prev.map((item) =>
          item.id === id ? { ...item, quantity: value } : item
        )
      );
    } catch (error) {
      console.log('Lỗi update:', error);
    }
  };

  // ✅ xoá sản phẩm (API)
  const removeItem = async (id) => {
    try {
      await requestAPI({
        method: 'DELETE',
        url: `/orders/remove-cart/${id}`,
      });

      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch (error) {
      console.log('Lỗi xoá:', error);
    }
  };

  // ✅ tính tổng tiền
  const subtotal = items.reduce(
    (sum, i) => sum + i.product.price * i.quantity,
    0
  );

  const onApplyCoupon = (data) => {
    alert('Áp dụng mã: ' + data.coupon);
  };

  return (
    <div className='cart-page'>
      <div className='cart-header'>
        <h2>Giỏ hàng</h2>
        <p>Trang chủ / Cửa hàng / Giỏ hàng</p>
      </div>

      <div className='cart-container'>
        {/* LEFT */}
        <div className='cart-list'>
          <div className='cart-title'>
            <span>Sản phẩm</span>
            <span>Số lượng</span>
            <span>Tổng</span>
          </div>

          {items.length === 0 ? (
            <p>Giỏ hàng trống</p>
          ) : (
            items.map((item) => (
              <div className='cart-item' key={item.id}>
                {/* PRODUCT */}
                <div className='product'>
                  <img src={item.product.image} alt='' />
                  <div>
                    <p>{item.product.name}</p>
                    <span>
                      {item.product.price.toLocaleString()}đ
                    </span>
                  </div>
                </div>

                {/* QUANTITY */}
                <div>
                  <input
                    type='number'
                    value={item.quantity}
                    min='1'
                    onChange={(e) =>
                      updateQty(item.id, parseInt(e.target.value))
                    }
                    className='qty-input'
                  />
                </div>

                {/* TOTAL */}
                <div className='total'>
                  {(item.product.price * item.quantity).toLocaleString()}đ
                </div>

                {/* REMOVE */}
                <button
                  className='remove'
                  onClick={() => removeItem(item.id)}
                >
                  ×
                </button>
              </div>
            ))
          )}

          <div className='cart-actions'>
            <button
              className='btn-light'
              onClick={() => navigate('/shop')}
            >
              ← Tiếp tục mua
            </button>
          </div>
        </div>

        {/* RIGHT */}
        <div className='cart-summary'>
          <form
            onSubmit={handleSubmit(onApplyCoupon)}
            className='coupon-box'
          >
            <input
              placeholder='Nhập mã giảm giá'
              {...register('coupon', {
                required: 'Vui lòng nhập mã',
              })}
            />
            <button>Áp dụng</button>
          </form>

          {errors.coupon && <small>{errors.coupon.message}</small>}

          <h3>Tổng giỏ hàng</h3>

          <div className='summary-row'>
            <span>Tạm tính</span>
            <span>{subtotal.toLocaleString()}đ</span>
          </div>

          <div className='summary-row total'>
            <span>Tổng</span>
            <span>{subtotal.toLocaleString()}đ</span>
          </div>

          <button className='btn-checkout'>
            <Link
              to='/checkout'
              className='text-decoration-none text-white'
            >
              Thanh toán
            </Link>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;